import java.rmi.*;
import java.net.*;
import java.util.*;
import java.io.*;

 
public class ChordUser
{
	int port;
	public ChordUser(int p) { //constructor
		port = p;
		Timer timer1 = new Timer();
		timer1.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() { //overriding the run on the timertask
				try {
					Chord chord = new Chord(port);
					System.out.println("Usage: \n\tjoin <port>\n\twrite <file> (the file must be an integer stored in the working directory, i.e, ./port/file");
					System.out.println("\tread <file>\n\tdelete <file>\n");
					System.out.println("\telect\n");
					Scanner scan= new Scanner(System.in);
					String delims = "[ ]+";
					String command = "";
		
					while (true) {
						String text= scan.nextLine();
						String[] tokens = text.split(delims); 
					
						if (tokens[0].equals("join") && tokens.length == 2) {
							try {
								chord.joinRing("localhost", Integer.parseInt(tokens[1]));
							} catch (IOException e) {
								System.out.println("Error joining the ring!");
							}
						}

						if (tokens[0].equals("print")) {
							chord.Print();
						}
		    
						if  (tokens[0].equals("write") && tokens.length == 2) {
							try {
								String path = ".\\"+  port +"\\"+Integer.parseInt(tokens[1])+".txt"; // path to file
								File f = new File(path);
								FileInputStream fis = null;
								fis = new FileInputStream(f);
								byte[] data = new byte[fis.available()];
								fis.read(data); // read data
								fis.close();
								chord.put(Integer.parseInt(tokens[1]), data); // put file into ring
							} catch (FileNotFoundException e1) {
								//e1.printStackTrace();
								System.out.println("File was not found!");
							} catch (IOException e) {
								//e.printStackTrace();
								System.out.println("Could not put file!");
							}
						}
					
						if (tokens[0].equals("read") && tokens.length == 2) {
							try {
								System.out.println(chord.get(Integer.parseInt(tokens[1])));
							} catch (IOException e) {
								System.out.println("Could not get file!");
							}
						}
					
						if (tokens[0].equals("delete") && tokens.length == 2) {
							try {
								chord.delete(Integer.parseInt(tokens[1]));
							} catch (IOException e) {
								System.out.println("Could not delete file!");
							}
						} //method to initialize leader election
		   
						if  (tokens[0].equals("elect")) {
							try {
								chord.startElection(); //elects an id of a chord
								
							} catch (IOException e) {
								System.out.println("Error electing the leader!");
							} //end catch
						} //end if for elect
					}
				} catch(RemoteException e) {
					System.out.println("Remote Exeption Caught.");
				}		
			}
		}, 1000, 1000); //the timer1
		// scheduleAtFixedRate(TimerTask task, Date firstTime, long period)
		// Schedules the specified task for repeated fixed-rate execution, beginning at the specified time.
    } //end chord user
    
    static public void main(String args[]) { //when create you pass in an arg what is the port number
    	if (args.length < 1 ) {  
    		throw new IllegalArgumentException("Parameter: <port>");
    	} try {
    		ChordUser chordUser = new ChordUser(Integer.parseInt(args[0])); //create new chorduser with that port number
    	} catch (Exception e) {
    		e.printStackTrace();
    		System.exit(1);
    	}
    } 
} //end class
