import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
import java.net.*;
import java.util.*;
import java.io.*;
 
public class Chord extends java.rmi.server.UnicastRemoteObject implements ChordMessageInterface
{
    public static final int M = 2;
    
    Registry registry;    // rmi registry for lookup the remote objects.
    ChordMessageInterface successor;
    ChordMessageInterface predecessor;
    ChordMessageInterface[] finger;
    ChordMessageInterface leader = null;
    ChordMessageInterface m = null;
    boolean participated = false;
    int nextFinger;
    int i;   		// GUID
    
    public void startElection() throws RemoteException {
    	try {
    		successor.electLeader(this);
        	m = this;
        	participated = true;
    	} catch (RemoteException e){
 	        e.printStackTrace();
        } 
    }
    
    public void electLeader(ChordMessageInterface w) throws RemoteException {
    	if (w.getId() > m.getId()) {//line 4
    		successor.electLeader(w);
    		m = w;
    		participated = true;
    	}
    	else if (w.getId() == this.getId()){
    		leader = this;
    		successor.setLeader(this);
    	}
    	else if ((w.getId() < m.getId()) && (!(participated))){
    		successor.electLeader(this);
    		participated = true;
    	}
    }
    
    public void setLeader(ChordMessageInterface w) throws RemoteException {
    	if (w.getId() != this.getId()) {
    		successor.setLeader(w);
    		leader = w;
    	}
    }
    
    public ChordMessageInterface rmiChord(String ip, int port)
    {	
        ChordMessageInterface chord = null;
        try{
            Registry registry = LocateRegistry.getRegistry(ip, port);
            chord = (ChordMessageInterface)(registry.lookup("Chord"));
            return chord;
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch(NotBoundException e){
            e.printStackTrace();
        }
        return null;
    }
    
    public Boolean isKeyInSemiCloseInterval(int key, int key1, int key2)
    {
       if (key1 < key2)
	      return (key > key1 && key <= key2);
	   else
	      return (key > key2 || key <= key1);
    }

    public Boolean isKeyInOpenInterval(int key, int key1, int key2)
    {
	   if (key1 < key2)
          return (key > key1 && key < key2);
	   else
	      return (key > key2 || key < key1);
    }
    
    
    public void put(int guid, byte[] data) throws RemoteException {
	
    }
    
    
    public byte[] get(int guid) throws RemoteException {
        return null;
        
    }
    
    public void delete(int guid) throws RemoteException {
        
    }
    
    public int getId() throws RemoteException {
        return i;
    }
    public boolean isAlive() throws RemoteException {
	    return true;
    }
    
    public ChordMessageInterface getPredecessor() throws RemoteException {
	    return predecessor;
    }
    
    public ChordMessageInterface locateSuccessor(int key) throws RemoteException {
	    if (key == i)
            throw new IllegalArgumentException("Key must be distinct that  " + i);
	    if (successor.getId() != i)
	    {
	      if (isKeyInSemiCloseInterval(key, i, successor.getId()))
	        return successor;
	      ChordMessageInterface j = closestPrecedingNode(key);
	      
          if (j == null)
	        return null;
	      return j.locateSuccessor(key);
        }
        return successor;
    }
    
    public ChordMessageInterface closestPrecedingNode(int key) throws RemoteException {
        int count = M-1;
        if (key == i)  throw new IllegalArgumentException("Key must be distinct that  " + i);
        for (count = M-1; count >= 0; count--) {
            if (finger[count] != null && isKeyInSemiCloseInterval(finger[count].getId(), i, key))
                return finger[count];
        }
        return successor;

    }
    
    public void joinRing(String ip, int port)  throws RemoteException {
        try{
            System.out.println("Get Registry to joining ring");
            Registry registry = LocateRegistry.getRegistry(ip, port);
            ChordMessageInterface chord = (ChordMessageInterface)(registry.lookup("Chord"));
            predecessor = null;
            System.out.println("Locating successor to joining ring" + port);
            
            successor = chord.locateSuccessor(i);
            if (successor != null)
                System.out.println("Successor " + successor.getId());
            
        }
        catch(RemoteException e){
            e.printStackTrace();
        }
        catch(NotBoundException e){
            e.printStackTrace();
        }   
    }
    
    public void stabilize() {
        try {
            ChordMessageInterface x = successor.getPredecessor();
                
            if (x != null && x.getId() != i &&
                (isKeyInOpenInterval(x.getId(), i, successor.getId()) || i == successor.getId()))
            {
                successor = x;
            }
            if (successor.getId() != getId())
            {
                successor.notify(this);
            }
        } catch(RemoteException e) {
            e.printStackTrace();
        } catch(NullPointerException e) {
            e.printStackTrace();
        }
    }
    
    public void notify(ChordMessageInterface j) throws RemoteException {
        if (predecessor == null || (predecessor != null && isKeyInOpenInterval(j.getId(), predecessor.getId(), i)))
            // transfer keys in the range [j,i) to j;
            predecessor = j;
    }
    
    public void fixFingers() {
        if (finger[nextFinger] != null)
            nextFinger = nextFinger + 1;
        if (nextFinger >= M)
            nextFinger = 0;
        try {
            finger[nextFinger] = locateSuccessor((i + (1 << nextFinger)));
        } catch(RemoteException e){
            e.printStackTrace();
        }

    }
    
    public void checkPredecessor() {
        try {
            if (predecessor != null) {
                if (!predecessor.isAlive())
                    predecessor = null;
            }
        } catch(RemoteException e) {
            predecessor = null;
        }
    }
       
    public Chord(final int port) throws RemoteException {
        int j;
        
	    finger = new ChordMessageInterface[M];
        for (j=0;j<M; j++){
	       finger[j] = null;
	    }
        i = port;
        m = this;
        predecessor = null;
	    successor = this;
	    Timer timer = new Timer();
	    timer.scheduleAtFixedRate(new TimerTask() {
	       @Override
	       public void run() {
	          stabilize();
	          fixFingers();
	          checkPredecessor();
	        }
	    }, 500, 500);
	    try{
           // create the registry and bind the name and object.
	       System.out.println("Starting RMI at port="+port);
	       registry = LocateRegistry.createRegistry( port );
           registry.rebind("Chord", this);
        }
        catch(RemoteException e){
	       throw e;
        } 
    }
    
    void Print()
    {   
	try {
		if (leader != null)
		      System.out.println("leader "+ leader.getId());
		if (successor != null)
			System.out.println("successor "+ successor.getId());
	  if (predecessor != null)
	      System.out.println("predecessor "+ predecessor.getId());
       }
        catch(RemoteException e){
	       System.out.println("Cannot retrive id");
        } 
    }
   
}