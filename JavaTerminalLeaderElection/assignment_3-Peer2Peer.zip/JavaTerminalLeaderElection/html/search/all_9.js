var searchData=
[
  ['notify',['notify',['../class_chord.html#a4de8b8464782dd96d88deeb35b2f27a2',1,'Chord.notify()'],['../interface_chord_message_interface.html#abbb77f94541073d79284d35f970e0eb4',1,'ChordMessageInterface.notify()']]]
];
