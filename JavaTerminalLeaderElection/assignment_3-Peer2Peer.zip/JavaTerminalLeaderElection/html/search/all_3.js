var searchData=
[
  ['fixfingers',['fixFingers',['../class_chord.html#a02763f74bbd986baa7e6567bf9dc3c95',1,'Chord']]]
];
