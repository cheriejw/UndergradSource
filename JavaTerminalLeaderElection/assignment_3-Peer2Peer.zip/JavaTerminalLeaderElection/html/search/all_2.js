var searchData=
[
  ['electleader',['electLeader',['../class_chord.html#a4e52e9f249bf6fbbfb8f75a1d924dcb0',1,'Chord.electLeader()'],['../interface_chord_message_interface.html#aa9549596b9da3f9028d987f35a42051d',1,'ChordMessageInterface.electLeader()']]]
];
